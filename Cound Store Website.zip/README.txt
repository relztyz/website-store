CIYRELZ Store
=============
Cara menjalankan:
1. Upload seluruh isi folder ini ke Vercel, Netlify, GitHub Pages, atau hosting biasa.
2. Buka index.html jika ingin mencoba secara lokal.
3. Nomor WhatsApp, DANA, nama penerima, dan URL QRIS bisa diubah lewat menu Pengaturan.
4. Untuk QRIS permanen, ganti assets/qris.jpg dengan gambar QRIS milik toko atau isi URL QRIS di Pengaturan.

Fitur:
- Responsive mobile/desktop
- Pencarian produk
- Filter kategori
- Modal checkout DANA / QRIS
- Tombol salin nomor DANA
- Konfirmasi pesanan via WhatsApp
- Pengaturan pembayaran tersimpan di localStorage
- FAQ accordion
