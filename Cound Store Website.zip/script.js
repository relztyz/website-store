const products = [
 {cat:"Sewa Bot",icon:"🤖",name:"Sewa Bot 1 Minggu",desc:"Sewa bot aktif selama 1 minggu, siap pakai instan.",price:2500},
 {cat:"Sewa Bot",icon:"🤖",name:"Sewa Bot 1 Bulan",desc:"Sewa bot aktif selama 1 bulan penuh.",price:5000},
 {cat:"Sewa Bot",icon:"🤖",name:"Sewa Bot 1 Tahun",desc:"Sewa bot aktif selama 1 tahun, hemat & stabil.",price:10000},
 {cat:"Sewa Bot",icon:"🤖",name:"Sewa Bot Permanen",desc:"Sewa bot aktif selamanya, tanpa perpanjangan.",price:15000},
 {cat:"Jadi Bot",icon:"🛠️",name:"Jadi Bot (SC Sakura AI) · 1 Minggu",desc:"Jasa jadi bot source code Mochi's AI, aktif 1 minggu.",price:13000},
 {cat:"Jadi Bot",icon:"🛠️",name:"Jadi Bot (SC Sakura AI) · 1 Bulan",desc:"Jasa jadi bot source code Mochi's AI, aktif 1 bulan.",price:20000},
 {cat:"Jadi Bot",icon:"🛠️",name:"Jadi Bot (SC Autoresbot) · 1 Minggu",desc:"Jasa jadi bot source code Autoresbot, aktif 1 minggu.",price:5000},
 {cat:"Jadi Bot",icon:"🛠️",name:"Jadi Bot (SC Autoresbot) · 1 Bulan",desc:"Jasa jadi bot source code Autoresbot/Jasher, aktif 1 bulan.",price:10000},
 {cat:"Panel Bot",icon:"🖥️",name:"Panel Bot 1GB",desc:"Panel hosting bot 1GB, aktif 30 hari.",price:2000},
 {cat:"Panel Bot",icon:"🖥️",name:"Panel Bot 2GB",desc:"Panel hosting bot 2GB, aktif 30 hari.",price:3000},
 {cat:"Panel Bot",icon:"🖥️",name:"Panel Bot 3GB",desc:"Panel hosting bot 3GB, aktif 30 hari.",price:4000},
 {cat:"Panel Bot",icon:"🖥️",name:"Panel Bot 4GB",desc:"Panel hosting bot 4GB, aktif 30 hari.",price:5000},
 {cat:"Panel Bot",icon:"🖥️",name:"Panel Bot 5GB",desc:"Panel hosting bot 5GB, aktif 30 hari.",price:6000},
 {cat:"Panel Bot",icon:"🖥️",name:"Panel Bot 6GB",desc:"Panel hosting bot 6GB, aktif 30 hari.",price:7000},
 {cat:"Panel Bot",icon:"🖥️",name:"Panel Bot 7GB",desc:"Panel hosting bot 7GB, aktif 30 hari.",price:8000},
 {cat:"Panel Bot",icon:"🖥️",name:"Panel Bot 8GB",desc:"Panel hosting bot 8GB, aktif 30 hari.",price:9000},
 {cat:"Panel Bot",icon:"🖥️",name:"Panel Bot 9GB",desc:"Panel hosting bot 9GB, aktif 30 hari.",price:10000},
 {cat:"Panel Bot",icon:"🖥️",name:"Panel Bot 10GB",desc:"Panel hosting bot 10GB, aktif 30 hari.",price:13000},
 {cat:"Panel Bot",icon:"🖥️",name:"Panel Bot Unlimited",desc:"Panel hosting bot unlimited, aktif 30 hari.",price:20000},
 {cat:"Script",icon:"📜",name:"Script Sakura AI · Full Update",desc:"2000+ fitur siap pakai, termasuk premium apikey, auto downloader, sewa & prem otomatis.",price:90000},
 {cat:"Script",icon:"📜",name:"Script Sakura AI · Full Update + Free Panel",desc:"Sama seperti Full Update, plus dapat panel gratis untuk hosting bot-nya.",price:120000},
 {cat:"Script",icon:"📜",name:"Script Sakura AI · Up Ress",desc:"Update source code untuk yang sudah pernah beli sebelumnya.",price:80000},
 {cat:"API Key",icon:"🔑",name:"API Key 1K Limit",desc:"API Key limit 1.000 request, aktif 30 hari.",price:8000},
 {cat:"API Key",icon:"🔑",name:"API Key 2K Limit",desc:"API Key limit 2.000 request, aktif 30 hari.",price:11000},
 {cat:"API Key",icon:"🔑",name:"API Key 5K Limit",desc:"API Key limit 5.000 request, aktif 30 hari.",price:18000},
 {cat:"API Key",icon:"🔑",name:"API Key 10K Limit",desc:"API Key limit 10.000 request, aktif 30 hari.",price:28000},
 {cat:"API Key",icon:"🔑",name:"API Key 20K Limit",desc:"API Key limit 20.000 request, aktif 30 hari.",price:45000},
 {cat:"Nokos",icon:"📱",name:"Nokos · Nogar",desc:"Nomor kosong tanpa garansi.",price:5000},
 {cat:"Nokos",icon:"📱",name:"Nokos · Garansi 1 Bulan",desc:"Nomor kosong dengan garansi 1 bulan.",price:11500},
 {cat:"Nokos",icon:"📱",name:"Nokos · Garansi 2 Bulan",desc:"Nomor kosong dengan garansi 2 bulan.",price:12900},
 {cat:"Nokos",icon:"📱",name:"Nokos · Garansi 1 Tahun Full (Manen)",desc:"Nomor kosong dengan garansi 1 tahun penuh.",price:29000},
 {cat:"Nokos",icon:"📱",name:"Nokos · Garansi Sampai Kartu Mati",desc:"Nomor kosong dengan garansi sampai kartu mati.",price:17300},
 {cat:"Nokos",icon:"📱",name:"Nokos · Garansi Seumur Hidup",desc:"Nomor kosong dengan garansi seumur hidup.",price:21300},
 {cat:"Nokos",icon:"📱",name:"Noktel · Nogar",desc:"Nomor telepon tanpa garansi.",price:8800},
 {cat:"Nokos",icon:"📱",name:"Nomail · Nogar",desc:"Nomor email tanpa garansi.",price:3500},
 {cat:"Nokos",icon:"📱",name:"Nokos All Apk",desc:"Untuk Gopay, Gojek, Shopee, Email dll.",price:3200},
 {cat:"Nokos",icon:"📱",name:"Web Nokos",desc:"Web nokos all negara.",price:12500}
];
const rupiah=n=>new Intl.NumberFormat("id-ID",{style:"currency",currency:"IDR",maximumFractionDigits:0}).format(n);
let activeCat="Semua", selected=null, settings=JSON.parse(localStorage.getItem("CoundSettings")||"{}");
settings.wa=settings.wa||"6285867837932";settings.dana=settings.dana||"6285867837932";settings.danaName=settings.danaName||"COUND STORE";
const tabs=document.getElementById("categoryTabs"), grid=document.getElementById("productGrid"), search=document.getElementById("searchInput");
const cats=["Semua",...new Set(products.map(p=>p.cat))];
tabs.innerHTML=cats.map(c=>`<button class="tab ${c==="Semua"?"active":""}" data-cat="${c}">${c}</button>`).join("");
function render(){
 const q=search.value.toLowerCase();
 const list=products.filter(p=>(activeCat==="Semua"||p.cat===activeCat)&&(p.name+" "+p.desc).toLowerCase().includes(q));
 grid.innerHTML=list.map((p,i)=>`<article class="product-card"><div class="product-icon">${p.icon}</div><h3>${p.name}</h3><p>${p.desc}</p><div class="card-bottom"><span class="price">${rupiah(p.price)}</span><button class="order-btn" data-index="${products.indexOf(p)}">💳 Pesan</button></div></article>`).join("");
 document.getElementById("emptyState").hidden=list.length!==0;
}
render();
tabs.addEventListener("click",e=>{if(e.target.matches(".tab")){activeCat=e.target.dataset.cat;document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x===e.target));render()}});
search.addEventListener("input",render);
grid.addEventListener("click",e=>{const b=e.target.closest(".order-btn");if(!b)return;selected=products[+b.dataset.index];document.getElementById("orderName").textContent=selected.name;document.getElementById("orderPrice").textContent=rupiah(selected.price);openModal("paymentModal")});
function openModal(id){document.getElementById(id).hidden=false;document.body.style.overflow="hidden"}
function closeModal(el){el.closest(".modal-backdrop").hidden=true;document.body.style.overflow=""}
document.querySelectorAll("[data-close]").forEach(b=>b.addEventListener("click",()=>closeModal(b)));
document.querySelectorAll(".modal-backdrop").forEach(m=>m.addEventListener("click",e=>{if(e.target===m)closeModal(m)}));
document.querySelectorAll(".pay-tab").forEach(b=>b.addEventListener("click",()=>{document.querySelectorAll(".pay-tab").forEach(x=>x.classList.remove("active"));b.classList.add("active");const q=b.dataset.method==="qris";document.getElementById("danaPanel").hidden=q;document.getElementById("qrisPanel").hidden=!q}));
function applySettings(){document.getElementById("danaNumber").textContent=settings.dana;document.getElementById("danaName").textContent=settings.danaName;document.getElementById("settingWa").value=settings.wa;document.getElementById("settingDana").value=settings.dana;document.getElementById("settingDanaName").value=settings.danaName;if(settings.qris)document.querySelector(".qris-img").src=settings.qris}
applySettings();
document.getElementById("copyDana").addEventListener("click",()=>{navigator.clipboard?.writeText(settings.dana);showToast("Nomor DANA disalin")});
document.getElementById("confirmWhatsapp").addEventListener("click",()=>{if(!selected)return;const text=`Halo admin Cound Store, saya ingin memesan:%0A%0AProduk: ${selected.name}%0AHarga: ${rupiah(selected.price)}%0A%0ASaya akan mengirim bukti pembayaran setelah transfer.`;window.open(`https://wa.me/${settings.wa.replace(/\D/g,"")}?text=${text}`,"_blank")});
document.getElementById("settingsBtn").addEventListener("click",()=>openModal("settingsModal"));document.getElementById("mobileSettings").addEventListener("click",()=>{document.getElementById("mobileMenu").classList.remove("open");openModal("settingsModal")});
document.getElementById("menuBtn").addEventListener("click",()=>document.getElementById("mobileMenu").classList.toggle("open"));
document.getElementById("saveSettings").addEventListener("click",()=>{settings={wa:document.getElementById("settingWa").value.trim(),dana:document.getElementById("settingDana").value.trim(),danaName:document.getElementById("settingDanaName").value.trim(),qris:document.getElementById("settingQris").value.trim()};localStorage.setItem("CoundSettings",JSON.stringify(settings));applySettings();closeModal(document.getElementById("saveSettings"));showToast("Pengaturan berhasil disimpan")});
function showToast(t){const x=document.getElementById("toast");x.textContent=t;x.classList.add("show");setTimeout(()=>x.classList.remove("show"),2200)}
